The given jupyter ntebook is used to download all the data realted to a seismic data in one day and plot them in a graph
It manily conists of 4 steps:
1. Getting the information about the data and time from the user to search the data for
2. Downloading the seismic data from https://pds-geosciences.wustl.edu/insight/urn-nasa-pds-insight_seis/data/xb/continuous_waveform/
3. Downloading other related data that could produce noise from https://atmos.nmsu.edu/PDS/data/PDS4/InSight/twins_bundle/data_calibrated/
4. Plotting the data in a graph and then marking the date and time so that the change that occured during that time can be viewed
